package com.example.sergio;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SergioApplication {

	public static void main(String[] args) {
		SpringApplication.run(SergioApplication.class, args);
	}

}
