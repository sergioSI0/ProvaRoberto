package com.example.sergio;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SergioApplicationTests {

	@Test
	void contextLoads() {
	}

}
